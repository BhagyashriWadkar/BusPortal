package com.zensar.bus.dao;

import org.springframework.data.repository.CrudRepository;

import com.zensar.bus.model.CostMODL;

public interface CostDAO extends CrudRepository<CostMODL, Integer> {

}
