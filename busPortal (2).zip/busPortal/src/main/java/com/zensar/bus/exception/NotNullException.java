package com.zensar.bus.exception;

public class NotNullException extends RuntimeException {

}
