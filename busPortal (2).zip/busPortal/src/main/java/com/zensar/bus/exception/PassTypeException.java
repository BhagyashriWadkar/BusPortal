package com.zensar.bus.exception;

public class PassTypeException extends RuntimeException {

}
